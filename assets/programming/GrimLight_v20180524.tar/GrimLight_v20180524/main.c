// PIC10F322 Configuration Bit Settings
// 'C' source line config statements
// CONFIG
#pragma config FOSC = INTOSC    // Oscillator Selection bits (INTOSC oscillator: CLKIN function disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable (Brown-out Reset disabled)
#pragma config WDTE = ON        // Watchdog Timer Enable (WDT enabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // MCLR Pin Function Select bit (MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config LVP = OFF        // Low-Voltage Programming Enable (High-voltage on MCLR/VPP must be used for programming)
#pragma config LPBOR = OFF      // Brown-out Reset Selection bits (BOR disabled)
#pragma config BORV = LO        // Brown-out Reset Voltage Selection (Brown-out Reset Voltage (Vbor), low trip point selected.)
#pragma config WRT = OFF        // Flash Memory Self-Write Protection (Write protection off)

#include <xc.h>
#include <pic10f322.h>

#define _XTAL_FREQ 4000000

#define STEP_VAL 60
//const unsigned char STEP_VAL=60;
enum p_state{OFF, ON}state;

//for rand())
unsigned int lfsr = 0xACE1u;
unsigned int bit1;

//more buffs
unsigned char val=0;
unsigned char val1=0;

//buffers for LED out
unsigned int buf;
unsigned int buf1;

//set starting setting
// 0 Steady
// 1 Flickering
// 2 Pulse
// 3 Burst
unsigned char LED_state=0;
unsigned char check=1;

void init_PWM();
unsigned int rand();
unsigned int pulse();
unsigned int burst();
void enter_sleep();
void init_osc();
void init();
void sleep_128ms();

void main(void) {
    //Setup prescalar for WDT
    //WDTPSx_bit used, default 2 seconds seems ok
    //WDTPS0=0;WDTPS1=1;WDTPS2=0;WDTPS3=1;WDTPS4=0;//1 s
    WDTPS0=1;WDTPS1=0;WDTPS2=0;WDTPS3=1;WDTPS4=0;//0.5 s
    //WDTPS0=0;WDTPS1=0;WDTPS2=0;WDTPS3=1;WDTPS4=0;//0.25 s

    //turn off voltage reference
    //FVREN = 0; //Default is off so no need to do manually
    VREGPM1 = 1; //Internal power regulator in power save
    //Weak internal pull-up, consumes lots of power, dont use
    //WPUA=0x04;

    //setup pins (inputs/outputs)
    ANSELA = 0x00; //all digital 
    PIE1bits.NCO1IE = 0; //RA2 as output
    CLKRCONbits.CLKROE = 0; //RA2 as output
    TRISA = 0x08; //RA3 input, rest output
    PORTA = 0x00;
    
    //Blink a few times when inserting new battery
    for(buf=0;buf<10;++buf)
    {
        LATAbits.LATA0 = !LATAbits.LATA0;
        LATAbits.LATA1 = !LATAbits.LATA1;
        sleep_128ms();
    }

    //Go to sleep, might accidently wake once
    enter_sleep();
    enter_sleep();

    unsigned char state_cnt=0;
    
    while(1){
        CLRWDT();
        
        //increase state_cnt if magnet is near Hall sensor
        //when count reach 100, change setting ~10s
        //if lower than 100, go to sleep        
        if(state_cnt >= 100 )
        {
            ++LED_state;
            
            state_cnt=50;
            check=0; //To prevent going to sleep when changing
        }
        else if(state_cnt>1 && PORTAbits.RA3){
            state_cnt=0;
            if(!check)check=1;
            else enter_sleep();
            
        }

        //LED effects
        switch(LED_state){
            case 0:
                buf=0xFFFF;
                buf1=0xFFFF;
                break;
            case 1:
                buf=rand();
                buf1=rand();
                break;
            case 2:
                buf=pulse();
                buf1=buf;
                break;
            case 3:
                buf=burst();
                buf1=buf;
                break;
            default:
                LED_state=0;
                break;
        }
        
        if(0==PORTAbits.RA3){
            ++state_cnt;
            if(state_cnt<50)
            {
                buf=0x0;
                buf1=0x0;
            }
        }
        
        PWM1DCH = buf>>2;
        PWM1DCL = buf<<6;
        PWM2DCH = buf1>>2;
        PWM2DCL = buf1<<6;

        while (!INTCONbits.TMR0IF);
        INTCONbits.TMR0IF = 0;
    }
}

void init(){
    init_osc();
    //setup timer for setting how fast effects change
    OPTION_REG = 0b00000110;
    INTCONbits.TMR0IF = 0;
    init_PWM(); 
}

void enter_sleep(){
    state=OFF;

    //Turn off PWM
    buf=0;
    PWM1DCH = buf>>2;
    PWM1DCL = buf<<6;
    PWM2DCH = buf>>2;
    PWM2DCL = buf<<6;
    
    //Turn off Hall
    PORTAbits.RA2 = 0; 
    
    //enter sleep, resume on WDT
    IRCF0 = 0; IRCF1 = 0; IRCF2 = 0;
    SLEEP();
    while(OFF==state){
        if(!STATUSbits.nTO){
            //woke due to WDT
            //Check if hall switch is pulled low, if, then wake (must first enable hall sensor)
            PORTAbits.RA2 = 1;  
            sleep_128ms();
            if(0 == PORTAbits.RA3){
                state = ON;
            }
            else{
                PORTAbits.RA2=0;    
                SLEEP();
            }
        }
    }
    check=0;
    PORTAbits.RA2 = 1; //Turn hall sensor on
    //sleep to make sure it is on before leaving sleep
    sleep_128ms();
    init();
}

void sleep_128ms(){
    WDTPS0=1;WDTPS1=1;WDTPS2=1;WDTPS3=0;WDTPS4=0;
    SLEEP();
    NOP();
    WDTPS0=1;WDTPS1=0;WDTPS2=0;WDTPS3=1;WDTPS4=0; //set back WDT    
}

void init_PWM() {
    //set up for pwm
    TRISA0 = 1;
    TRISA1 = 1;
    PWM1CON = 0x00;
    PWM2CON = 0x00;
    PR2 = 0x3F; //dunno 
    PWM1DCH = 0x00;
    PWM1DCL = 0x00;
    PWM2DCH = 0x00;
    PWM2DCL = 0x00;
    ////set up Timer2
    PIR1bits.TMR2IF = 0;
    T2CON = 0b00000100; //timer on, no post scalar, prescaler is 1
    //enable pwm
    PWM1CONbits.PWM1EN = 1;
    PWM2CON0bits.PWM2EN = 1;
    while (!PIR1bits.TMR2IF); //wait for overflow
    TRISA0 = 0;
    TRISA1 = 0;
    PWM1CONbits.PWM1OE = 1;
    PWM2CON0bits.PWM2OE = 1;
    return;
}
//not really rand, https://en.wikipedia.org/wiki/Linear-feedback_shift_register
unsigned int rand(){
  bit1  = ((lfsr >> 0) ^ (lfsr >> 2) ^ (lfsr >> 3) ^ (lfsr >> 5) ) & 1;
  return lfsr =  (lfsr >> 1) | (bit1 << 15);
}

void init_osc(){
    #if (4000000 == _XTAL_FREQ) 
        IRCF0 = 1;
        IRCF1 = 0;
        IRCF2 = 1; //4MHz, 0 0 0 is 31kHz low freq oscillator
    #endif
    #if (8000000 == _XTAL_FREQ) 
        IRCF0 = 0;
        IRCF1 = 1;
        IRCF2 = 1;
    #endif
}
/*
unsigned int pulse(){
    //static int val=0;
    val+=6;
    if(val>0x16F)val=0;//3;
    if(val>0x10F)return 3;//3;
    return val;
}
*/
unsigned int pulse(){
    //static int val=0;
    
    ++val1;
    if(val1<0x20)val+=6;
    if(val1>0x20)val-=6;
    if(val1>0x3E)
    {
        val1=0;
        val=0;
    }
   
    return val;
}
unsigned int burst(){
    //static unsigned char val=0;
    //static unsigned char val1=0;
    val+=STEP_VAL;
    
    if(val>230)++val1;
    
    if(val1>5){
        ++val1;
        if(val1>100)val1=0;
        return 0x0003;
    }
    
    if(val<0x7F)return 0xFFFF;
    return 0x0000;
    
}